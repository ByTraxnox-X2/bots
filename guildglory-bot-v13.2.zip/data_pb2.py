# -*- coding: utf-8 -*-
# ╔══════════════════════════════════════════════════════════════════════╗
# ║                                                                      ║
# ║   ██████╗  █████╗ ███████╗██╗███╗   ██╗                              ║
# ║   ██╔══██╗██╔══██╗██╔════╝██║████╗  ██║                              ║
# ║   ██████╔╝███████║█████╗  ██║██╔██╗ ██║                              ║
# ║   ██╔══██╗██╔══██║██╔══╝  ██║██║╚██╗██║                              ║
# ║   ██║  ██║██║  ██║██║     ██║██║ ╚████║                              ║
# ║   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═══╝                              ║
# ║                                                                      ║
# ║                  ★   R A F I N   T x T   ★                           ║
# ║                  P R E M I U M   E D I T I O N                       ║
# ║                                                                      ║
# ╚══════════════════════════════════════════════════════════════════════╝
#
#  ┌──────────────────────────────────────────────────────────────────┐
#  │  Project      :  data                                             │
#  │  Module       :  data_pb2                                         │
#  │  Author       :  RAFIN TxT                                        │
#  │  Protobuf Ver :  4.25.1                                           │
#  │  Language     :  Python                                           │
#  │  Status       :  Auto-generated — DO NOT EDIT                     │
#  └──────────────────────────────────────────────────────────────────┘
#
#  © RAFIN TxT — All rights reserved.
#
"""RAFIN TxT — data Protocol Buffer Module.

Premium Edition — auto-generated protocol buffer code.
Source: data.proto
"""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
# @@protoc_insertion_point(imports)

_sym_db = _symbol_database.Default()




DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\ndata.proto\x12\x05proto\"\xa4\x05\n\x08response\x12\n\n\x02id\x18\x01 \x01(\r\x12\x14\n\x0cspecial_code\x18\x02 \x01(\t\x12\x12\n\ntimestamp1\x18\x03 \x01(\r\x12\x0f\n\x07value_a\x18\x04 \x01(\r\x12\x13\n\x0bstatus_code\x18\x05 \x01(\r\x12\x10\n\x08sub_type\x18\x06 \x01(\r\x12\x0f\n\x07version\x18\x07 \x01(\r\x12\r\n\x05level\x18\x08 \x01(\r\x12\r\n\x05\x66lags\x18\t \x01(\r\x12\x17\n\x0fwelcome_message\x18\x0c \x01(\t\x12\x0e\n\x06region\x18\r \x01(\t\x12\x15\n\rjson_metadata\x18\x0e \x01(\t\x12\x13\n\x0b\x62ig_numbers\x18\x0f \x01(\t\x12\x0f\n\x07\x62\x61lance\x18\x14 \x01(\r\x12\r\n\x05score\x18\x16 \x01(\r\x12\x10\n\x08upgrades\x18! \x01(\r\x12\x14\n\x0c\x61\x63hievements\x18# \x01(\r\x12\x16\n\x0etotal_playtime\x18$ \x01(\r\x12\x0e\n\x06\x65nergy\x18% \x01(\r\x12\x0c\n\x04rank\x18& \x01(\r\x12\n\n\x02xp\x18\' \x01(\r\x12\x12\n\ntimestamp2\x18( \x01(\r\x12\x12\n\nerror_code\x18) \x01(\r\x12\x13\n\x0blast_active\x18, \x01(\r\x12\x30\n\rguild_details\x18/ \x01(\x0b\x32\x19.proto.response.GuildInfo\x12\x13\n\x0b\x65mpty_field\x18\x31 \x01(\t\x1a\x97\x01\n\tGuildInfo\x12\x0e\n\x06region\x18\x01 \x01(\t\x12\x0f\n\x07\x63lan_id\x18\x02 \x01(\r\x12\x16\n\x0emembers_online\x18\x03 \x01(\r\x12\x15\n\rtotal_members\x18\x04 \x01(\r\x12\x10\n\x08regional\x18\x05 \x01(\r\x12\x13\n\x0breward_time\x18\x06 \x01(\r\x12\x13\n\x0b\x65xpire_time\x18\x07 \x01(\rb\x06proto3')

_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'data_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
  DESCRIPTOR._options = None
  _globals['_RESPONSE']._serialized_start=22
  _globals['_RESPONSE']._serialized_end=698
  _globals['_RESPONSE_GUILDINFO']._serialized_start=547
  _globals['_RESPONSE_GUILDINFO']._serialized_end=698
# @@protoc_insertion_point(module_scope)

# ╔══════════════════════════════════════════════════════════════════════╗
# ║   End of file  —  RAFIN TxT  —  Premium Edition                      ║
# ╚══════════════════════════════════════════════════════════════════════╝